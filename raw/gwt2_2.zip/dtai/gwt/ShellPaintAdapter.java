/****************************************************************
 **  Copyright 1997 by DTAI Incorporated, All Rights Reserved  **
 ****************************************************************
 **
 **  $Id: ShellPaintAdapter.java,v 1.1 1997/10/01 16:51:33 cvs Exp $
 **
 **  $Source: /cvs/classes/dtai/gwt/ShellPaintAdapter.java,v $
 **
 ****************************************************************/

package dtai.gwt;

/**
 * Class ShellPaintAdapter
 * @version 1.1
 * @author  DTAI, inc.
 */
public class ShellPaintAdapter implements ShellPaintListener {

	/**
	 * @param e   The ShellPaint event
	 */
	public void regionUpdated(ShellPaintEvent e) {
	}
}

